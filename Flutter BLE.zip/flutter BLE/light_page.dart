import 'dart:async';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:flutter_blue_plus/flutter_blue_plus.dart';
import 'theme_provider.dart';
import 'bottom_nav_bar.dart';

class LightPage extends StatefulWidget {
  const LightPage({super.key});

  @override
  _LightPageState createState() => _LightPageState();
}

class _LightPageState extends State<LightPage> {
  BluetoothDevice? connectedDevice;
  BluetoothCharacteristic? setCharacteristic;
  BluetoothCharacteristic? getCharacteristic;

  final String serviceUuid = "4fafc201-1fb5-459e-8fcc-c5c9c331914b";
  final String setCharacteristicUuid = "beb5483e-36e1-4688-b7f5-ea07361b26a8";
  final String getCharacteristicUuid = "6d140001-bcb0-4c43-a293-b21a53dbf9f5";

  bool light = false;
  String lightIntensity = 'LOW';

  @override
  void initState() {
    super.initState();
    connectToDevice();
  }

  Future<void> connectToDevice() async {
    try {
      List<BluetoothDevice> devices = FlutterBluePlus.connectedDevices;
      for (BluetoothDevice device in devices) {
        if (device.name == 'light_up_cane') {
          connectedDevice = device;

          // Services en characteristics ontdekken
          List<BluetoothService> services = await connectedDevice!.discoverServices();
          for (BluetoothService service in services) {
            if (service.uuid.toString() == serviceUuid) {
              for (BluetoothCharacteristic characteristic in service.characteristics) {
                if (characteristic.uuid.toString() == setCharacteristicUuid) {
                  setCharacteristic = characteristic;
                } else if (characteristic.uuid.toString() == getCharacteristicUuid) {
                  getCharacteristic = characteristic;
                  await getCharacteristic!.setNotifyValue(true);
                  getCharacteristic!.value.listen((value) {
                    // Ontvang gegevens van het apparaat
                    String data = String.fromCharCodes(value);
                    _handleReceivedData(data);
                  });
                }
              }
            }
          }
        }
      }
    } catch (e) {
      print("Error connecting to device: $e");
    }
  }

  void _handleReceivedData(String data) {
    List<String> values = data.split(" ");
    if (values.length >= 6) {
      setState(() {
        lightIntensity = values[1] == '30' ? 'LOW' : values[1] == '60' ? 'MID' : 'HIGH';
        light = values[5] == '0' ? false : true;
      });
    }
  }

  Future<void> _sendIntensityData(String type, int intensityValue) async {
    try {
      if (setCharacteristic != null) {
        // Gebruik BLE om gegevens te verzenden
        String dataString = "$type $intensityValue";
        await setCharacteristic!.write(dataString.codeUnits, withoutResponse: false);
      }
    } catch (e) {
      print("Error sending data: $e");
    }
  }

  @override
  void dispose() {
    _disconnectFromDevice();
    super.dispose();
  }

  void _disconnectFromDevice() {
    if (connectedDevice != null) {
      try {
        connectedDevice!.disconnect();
      } catch (e) {
        print("Error disconnecting device: $e");
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    // Access ThemeProvider
    final themeProvider = Provider.of<ThemeProvider>(context);

    // Get screen dimensions for dynamic scaling
    var screenWidth = MediaQuery.of(context).size.width;
    var screenHeight = MediaQuery.of(context).size.height;

    // Adjust padding and spacing dynamically based on screen size
    double horizontalPadding = screenWidth * 0.1; // 10% padding
    double buttonSpacing = screenHeight * 0.05; // Spacing between buttons

    return Scaffold(
      backgroundColor: themeProvider.themeMode == ThemeMode.dark
          ? Colors.grey[800]
          : Colors.grey[300],
      body: SafeArea(
        child: Padding(
          padding: EdgeInsets.symmetric(horizontal: horizontalPadding),
          child: LayoutBuilder(
            builder: (context, constraints) {
              double maxWidth = constraints.maxWidth - 40;

              return Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  // Header
                  Center(
                    child: Container(
                      width: screenWidth * 0.8,
                      padding: EdgeInsets.symmetric(vertical: screenHeight * 0.005),
                      decoration: BoxDecoration(
                        color: themeProvider.themeMode == ThemeMode.dark
                            ? Colors.grey[850]
                            : Colors.grey[400],
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Center(
                        child: Text(
                          'LIGHT',
                          style: TextStyle(
                            color: themeProvider.accentColor,
                            fontSize: screenWidth * 0.08,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ),
                  ),
                  SizedBox(height: buttonSpacing),

                  // Light Toggle
                  _buildSwitchRow('LIGHT', light, (value) {
                    setState(() {
                      light = value;
                      _sendIntensityData('LightSwitch', light ? 1 : 0);
                      _sendIntensityData('Light', lightIntensity == 'LOW' ? 30 : lightIntensity == 'MID' ? 60 : 100);
                    });
                  }, maxWidth, screenWidth, themeProvider),
                  SizedBox(height: buttonSpacing),

                  // Light Intensity Toggle
                  _buildLightIntensityRow('LIGHT INTENSITY', lightIntensity, maxWidth, screenWidth, themeProvider),
                  SizedBox(height: buttonSpacing),

                  const Spacer(),
                  SizedBox(height: buttonSpacing),
                ],
              );
            },
          ),
        ),
      ),
      bottomNavigationBar: const BottomNavBar(currentPage: "Light"),
    );
  }

  Widget _buildSwitchRow(String label, bool switchValue, Function(bool) onChanged, double maxWidth, double screenWidth, ThemeProvider themeProvider) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Expanded(
          child: Text(
            label,
            style: TextStyle(
              color: themeProvider.accentColor,
              fontSize: screenWidth * 0.045,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
        Container(
          width: maxWidth / 3,
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
          child: Center(
            child: Switch(
              value: switchValue,
              onChanged: (bool value) {
                onChanged(value);
              },
              activeColor: themeProvider.accentColor,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildLightIntensityRow(String label, String value, double maxWidth, double screenWidth, ThemeProvider themeProvider) {
    List<String> intensities = ['LOW', 'MID', 'HIGH'];
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Expanded(
          child: Text(
            label,
            style: TextStyle(
              color: themeProvider.accentColor,
              fontSize: screenWidth * 0.045,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
        GestureDetector(
          onTap: () {
            setState(() {
              int currentIndex = intensities.indexOf(value);
              lightIntensity = intensities[(currentIndex + 1) % intensities.length];
              _sendIntensityData('Light', lightIntensity == 'LOW' ? 30 : lightIntensity == 'MID' ? 60 : 100);
            });
          },
          child: Container(
            width: maxWidth / 3,
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            decoration: BoxDecoration(
              color: themeProvider.themeMode == ThemeMode.dark
                  ? Colors.grey[850]
                  : Colors.grey[400],
              borderRadius: BorderRadius.circular(5),
            ),
            child: Center(
              child: Text(
                value,
                style: TextStyle(
                  color: themeProvider.accentColor,
                  fontSize: screenWidth * 0.045,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }
}
