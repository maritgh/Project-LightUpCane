import 'dart:async';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:flutter_blue_plus/flutter_blue_plus.dart';
import 'theme_provider.dart';
import 'notification_provider.dart';
import 'bottom_nav_bar.dart';

class AudioPage extends StatefulWidget {
  const AudioPage({super.key});

  @override
  _AudioPageState createState() => _AudioPageState();
}

class _AudioPageState extends State<AudioPage> {
  BluetoothDevice? connectedDevice;
  BluetoothCharacteristic? setCharacteristic;
  BluetoothCharacteristic? getCharacteristic;

  final String serviceUuid = "4fafc201-1fb5-459e-8fcc-c5c9c331914b";
  final String setCharacteristicUuid = "beb5483e-36e1-4688-b7f5-ea07361b26a8";
  final String getCharacteristicUuid = "6d140001-bcb0-4c43-a293-b21a53dbf9f5";

  bool haptic = true;
  double hapticIntensity = 25.0;
  bool buzzer = true;
  double buzzerIntensity = 75.0;

  @override
  void initState() {
    super.initState();
    connectToDevice();
  }

Future<void> connectToDevice() async {
    try {
      List<BluetoothDevice> devices = FlutterBluePlus.connectedDevices;
      for (BluetoothDevice device in devices) {
        if (device.name == 'light_up_cane') {
          connectedDevice = device;

          // Services en characteristics ontdekken
          List<BluetoothService> services = await connectedDevice!.discoverServices();
          for (BluetoothService service in services) {
            if (service.uuid.toString() == serviceUuid) {
              for (BluetoothCharacteristic characteristic in service.characteristics) {
                if (characteristic.uuid.toString() == setCharacteristicUuid) {
                  setCharacteristic = characteristic;
                } else if (characteristic.uuid.toString() == getCharacteristicUuid) {
                  getCharacteristic = characteristic;
                  await getCharacteristic!.setNotifyValue(true);
                  getCharacteristic!.value.listen((value) {
                    // Ontvang gegevens van het apparaat
                    String data = String.fromCharCodes(value);
                    _handleReceivedData(data);
                  });
                }
              }
            }
          }
        }
      }
    } catch (e) {
      print("Error connecting to device: $e");
    }
  }


  void _handleReceivedData(String data) {
    List<String> values = data.split(" ");
    if (values.length >= 6) {
      setState(() {
        hapticIntensity = values[4] == '0' ? 0 : values[4] == '70' ? 25 : values[4] == '80' ? 50 : values[4] == '90' ? 75 : 100;
        haptic = hapticIntensity == 0 ? false : true;
        buzzerIntensity = values[2] == '0' ? 0 : values[2] == '1' ? 25 : values[2] == '3' ? 50 : values[2] == '5' ? 75 : 100;
        buzzer = buzzerIntensity == 0 ? false : true;
      });
    }
  }

  Future<void> _sendIntensityData(String type, double intensityValue) async {
    try {
      if (setCharacteristic != null) {
        // Gebruik BLE om gegevens te verzenden
        String dataString = "$type $intensityValue";
        await setCharacteristic!.write(dataString.codeUnits, withoutResponse: false);
      }
    } catch (e) {
      print("Error sending data: $e");
    }
  }

  @override
  void dispose() {
    _disconnectFromDevice();
    super.dispose();
  }

  void _disconnectFromDevice() {
    if (connectedDevice != null) {
      try {
        connectedDevice!.disconnect();
      } catch (e) {
        print("Error disconnecting device: $e");
      }
    }
  }

 @override
  Widget build(BuildContext context) {
    // Access ThemeProvider
    final themeProvider = Provider.of<ThemeProvider>(context);
    final notificationProvider = Provider.of<NotificationProvider>(context);

    // Get screen dimensions for dynamic scaling
    var screenWidth = MediaQuery.of(context).size.width;
    var screenHeight = MediaQuery.of(context).size.height;

    // Adjust padding and spacing dynamically based on screen size
    double horizontalPadding = screenWidth * 0.1; // 10% padding
    double buttonSpacing = screenHeight * 0.05; // Spacing between buttons

    return Scaffold(
      backgroundColor: themeProvider.themeMode == ThemeMode.dark
          ? Colors.grey[800] // Dark background for dark theme
          : Colors.grey[300], // Light background for light theme
      body: SafeArea(
        child: Container(
          // // Apply a gray filter using a semi-transparent color overlay
          // decoration: BoxDecoration(
          //   color: Colors.grey[300], // Base color for the background
          //   backgroundBlendMode: BlendMode.overlay, // Blend mode for the gray filter
          // ),
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: horizontalPadding),
            child: LayoutBuilder(
              builder: (context, constraints) {
                double maxWidth = constraints.maxWidth - 40; // Ensure padding from edges

                return Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    // Audio Title
                    Center(
                      child: Container(
                        width: screenWidth * 0.8,
                        padding: EdgeInsets.symmetric(vertical: screenHeight * 0.005),
                        decoration: BoxDecoration(
                          color: themeProvider.themeMode == ThemeMode.dark
                              ? Colors.grey[850]
                              : Colors.grey[400],
                          borderRadius: BorderRadius.circular(20), // Rounded corners for the status header
                        ),
                        child: Center(
                          child: Text(
                            'AUDIO',
                            style: TextStyle(
                              color: themeProvider.accentColor, // Use accent color from ThemeProvider
                              fontSize: screenWidth * 0.08, // Dynamic font size based on screen width
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ),
                    ),
                    SizedBox(height: buttonSpacing), // Space between header and rows

                    // Notifications Toggle
                    _buildSwitchRow('NOTIFICATIONS', notificationProvider.notifications, (value) {
                      setState(() {
                        notificationProvider.notifications = value;
                        // _sendIntensityData('Find', 0);
                      });
                    }, maxWidth, screenWidth, themeProvider),
                    SizedBox(height: buttonSpacing), // Spacing between rows

                    // Haptic Toggle
                    _buildSwitchRow('HAPTIC', haptic, (value) {
                      setState(() {
                        haptic = value;
                        if (haptic) {
                          _sendIntensityData('Haptic', hapticIntensity == 25 ? 70 : hapticIntensity == 50 ? 80 : hapticIntensity == 75 ? 90 : 100);
                        } else {
                          _sendIntensityData('Haptic', 0.0);
                        }
                      });
                    }, maxWidth, screenWidth, themeProvider),
                    SizedBox(height: buttonSpacing), // Spacing between rows

                    // Haptic Intensity Button
                    _buildIntensityButtonRow('HAPTIC INTENSITY', hapticIntensity, () {
                      setState(() {
                        if (haptic) {
                          hapticIntensity = _cycleIntensity(hapticIntensity); // Ensure this is a double
                          _sendIntensityData('Haptic', hapticIntensity == 25 ? 70 : hapticIntensity == 50 ? 80 : hapticIntensity == 75 ? 90 : 100);
                        } else {
                          _sendIntensityData('Haptic', 0.0);
                        }
                      });
                    }, maxWidth, screenWidth, themeProvider),
                    SizedBox(height: buttonSpacing), // Spacing between rows

                    // Buzzer Toggle
                    _buildSwitchRow('BUZZER', buzzer, (value) {
                      setState(() {
                        buzzer = value;
                        if (buzzer) {
                          _sendIntensityData('Buzzer', buzzerIntensity == 25 ? 1 : buzzerIntensity == 50 ? 3 : buzzerIntensity == 75 ? 5 : 10);
                        } else {
                          _sendIntensityData('Buzzer', 0.0);
                        }
                      });
                    }, maxWidth, screenWidth, themeProvider),
                    SizedBox(height: buttonSpacing), // Spacing between rows

                    // Buzzer Intensity Button
                    _buildIntensityButtonRow('BUZZER INTENSITY', buzzerIntensity, () {
                      setState(() {
                        if (buzzer) {
                          buzzerIntensity = _cycleIntensity(buzzerIntensity); // Ensure this is a double
                          _sendIntensityData('Buzzer', buzzerIntensity == 25 ? 1 : buzzerIntensity == 50 ? 3 : buzzerIntensity == 75 ? 5 : 10);
                        } else {
                          _sendIntensityData('Buzzer', 0.0);
                        }
                      });
                    }, maxWidth, screenWidth, themeProvider),
                    SizedBox(height: buttonSpacing), // Larger space before the return button

                    const Spacer(),

                    SizedBox(height: buttonSpacing),
                  ],
                );
              },
            ),
          ),
        ),
      ),
      bottomNavigationBar: const BottomNavBar(currentPage: "Audio"),
    );
  }

  Widget _buildHeader(String title, double screenWidth, ThemeProvider themeProvider) {
    return Center(
      child: Container(
        width: screenWidth * 0.8,
        padding: const EdgeInsets.symmetric(vertical: 10),
        decoration: BoxDecoration(
          color: themeProvider.themeMode == ThemeMode.dark
              ? Colors.grey[850]
              : Colors.grey[400],
          borderRadius: BorderRadius.circular(20),
        ),
        child: Center(
          child: Text(
            title,
            style: TextStyle(
              color: themeProvider.accentColor,
              fontSize: screenWidth * 0.08,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildSwitchRow(String label, bool value, Function(bool) onChanged, double maxWidth, double screenWidth, ThemeProvider themeProvider) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          label,
          style: TextStyle(
            color: themeProvider.accentColor,
            fontSize: screenWidth * 0.045,
            fontWeight: FontWeight.bold,
          ),
        ),
        Switch(
          value: value,
          onChanged: onChanged,
          activeColor: themeProvider.accentColor,
        ),
      ],
    );
  }

  Widget _buildIntensityButtonRow(String label, double value, Function() onPressed, double maxWidth, double screenWidth, ThemeProvider themeProvider) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          label,
          style: TextStyle(
            color: themeProvider.accentColor,
            fontSize: screenWidth * 0.045,
            fontWeight: FontWeight.bold,
          ),
        ),
        TextButton(
          onPressed: onPressed,
          child: Text(
            '${value.toInt()}%',
            style: TextStyle(
              color: themeProvider.accentColor,
              fontSize: screenWidth * 0.045,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
      ],
    );
  }

  double _cycleIntensity(double currentValue) {
    switch (currentValue) {
      case 25.0:
        return 50.0;
      case 50.0:
        return 75.0;
      case 75.0:
        return 100.0;
      case 100.0:
        return 25.0;
      default:
        return 25.0;
    }
  }
}
